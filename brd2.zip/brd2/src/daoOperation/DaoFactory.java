package daoOperation;

public class DaoFactory 
{

	public static CustomerDaoI factoryIntial(String name)
	{
		if(name.equalsIgnoreCase("oracle"))
		{
			return new CustomerDao();
		}
	/*	else if(name.equalsIgnoreCase("mysql"))
		{
			return new MySQL();
		}
		else if(name.equalsIgnoreCase("sqlserver"))
		{
			return new SqlServer();
		}
		else {
			System.out.println("Wrong choice.. ");
			return  null;
	}*/
		return null;
	}
	
}
