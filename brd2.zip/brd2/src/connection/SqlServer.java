package connection;

import java.sql.Connection;

public class SqlServer implements ConnectionI{

	@Override
	public Connection myConnection() {
		// TODO Auto-generated method stub
		return null;
	}

}
