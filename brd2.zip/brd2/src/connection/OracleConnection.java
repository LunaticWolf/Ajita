package connection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class OracleConnection implements ConnectionI 
{

	@Override
	public Connection myConnection() {
		Connection conn = null;
		Properties prop=new Properties();
		InputStream is=null;
		try 
		{
			is=new FileInputStream("D:\\nsbt18060090\\brd2\\config.properties");
			prop.load(is);
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());	//load class
			conn=DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("user"),prop.getProperty("pass"));
					
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return conn;
	}

	
	
}
