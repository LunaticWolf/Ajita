package daoOperation;


import java.util.List;
import java.util.Set;

import entityPojo_customer.Customer;


public interface CustomerDaoI {
	
	public List<Customer> fetchAll();
	public int updateCustomer(Customer customer);
	public int deleteCustomer(String id);
	public int addCustomer(Customer customer);
	public Customer viewupdate(String id);
	public Set<String> fetch_customer_code();
	public List<Customer> fetchAllByName();
	public List<Customer> fetchAllByCode();
	
	
}
