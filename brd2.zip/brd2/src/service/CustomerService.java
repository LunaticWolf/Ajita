package service;


import java.util.List;
import java.util.Set;
import daoOperation.CustomerDaoI;
import daoOperation.DaoFactory;
import entityPojo_customer.Customer;

public class CustomerService implements CustomerServiceI
{
	CustomerDaoI dao=DaoFactory.factoryIntial("oracle");
	Validation validation=new Validation();
	@Override
	public List<Customer> viewCustomer()
	{
		
		List<Customer> customers=dao.fetchAll();
		return customers;
	}
	
	@Override
	public int delete(String id)
	{
		int count=dao.deleteCustomer(id);
		return count;
	}
	
	@Override
	public int add(Customer customer)
	{
		int count=0;
		Set<String> set=dao.fetch_customer_code();
		boolean code=validation.validCustomerCode(customer, set);
		if(code==true)
		{
		count=dao.addCustomer(customer);
		return count;
		}
		else
		return count;
	}
	
	@Override
	public Customer updateCustomer(String customerCode)
	{
		Customer customer=dao.viewupdate(customerCode);
		return customer;
	}
	
	@Override
	public int update(Customer customer)
	{
		int count=dao.updateCustomer(customer);
		return count;
	}
	
	@Override
	public boolean checkCode(String customerCode)
	{
		Set<String> set=dao.fetch_customer_code();
		if(set.contains(customerCode))
		return true;
		else
			return false;
	}
	
	@Override
	public List<Customer> fetchByName()
	{
		List<Customer> customers=dao.fetchAllByName();
		return customers;
	}
	
	@Override
	public List<Customer> fetchByCode()
	{
		List<Customer> customers=dao.fetchAllByCode();
		return customers;
	}
}
