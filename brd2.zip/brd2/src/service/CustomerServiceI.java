package service;

import java.util.List;


import entityPojo_customer.Customer;

public interface CustomerServiceI 

{

	public List<Customer> viewCustomer();
	public int delete(String id);
	public int add(Customer customer);
	public Customer updateCustomer(String customerCode);
	public int update(Customer customer);
	public boolean checkCode(String customerCode);
	public List<Customer> fetchByName();
	public List<Customer> fetchByCode();
	
	
}
